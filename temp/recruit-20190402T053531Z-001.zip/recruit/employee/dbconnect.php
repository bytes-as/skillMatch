<?php
  $dbcon = mysqli_connect('localhost','root','','recruit') or die("Na hobe");
?>
