<?php

    require_once 'dbconnect.php';
    $errors = array();
    

?>
