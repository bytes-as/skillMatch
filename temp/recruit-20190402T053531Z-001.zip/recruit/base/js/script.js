function openSeekerLogin() {
    window.location="logins.php";
}

function openPosterLogin() {
    window.location="loginp.php";
}

function changeOpacity(i) {
    document.getElementById(i).style.opacity='1';
}

