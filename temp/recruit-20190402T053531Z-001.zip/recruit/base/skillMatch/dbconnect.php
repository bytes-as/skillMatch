<?php
  $host = "localhost";
  $user = "root";
  $dbpass = "@parammangal";
  $dbname = "MiniProjDBMS";
  $dbcon = mysqli_connect($host,$user,$dbpass,$dbname);
?>
