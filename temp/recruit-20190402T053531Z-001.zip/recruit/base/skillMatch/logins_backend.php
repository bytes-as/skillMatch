<?php
require_once 'dbconnect.php';
echo "<script type='text/javascript'>alert( 'done' );</script>";

$email_or_username = $_POST["username_or_email"];
$password = $_POST["password"];


#$password = md5($password);

$query1 = "SELECT * FROM MiniProjDBMS.loginInfo WHERE username='$email_or_username' AND password='$password'";

#echo "<script type='text/javascript'>alert( '$email_or_username'+'$password' );</script>";
#echo "<script type='text/javascript'>alert( '$query1' );</script>";
    

$result1 = mysqli_query($dbcon, $query1);
$numResults1 = mysqli_num_rows($result1);

#echo "<script type='text/javascript'>alert( '$numResults1'+'$password' );</script>";

if($numResults1 == 1) {
    $row1 = mysqli_fetch_row($result);
    session_start();
    #echo "<script type='text/javascript'>alert( 'sahi hai' );</script>";
    $_SESSION['employee_id'] = $row1['employee_id'];
    $_SESSION['user_type'] = 1;
    header('location:job.php');
} else {
    #echo "<script type='text/javascript'>alert( 'chi chi' );</script>";
    header('location:logins.php');
}
?>
