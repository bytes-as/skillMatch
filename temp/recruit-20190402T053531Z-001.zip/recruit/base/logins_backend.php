<?php
require_once 'dbconnect.php';
echo "<script type='text/javascript'>alert( 'done' );</script>";

$email_or_username = $_POST["username_or_email"];
$password = $_POST["password"];


#$password = md5($password);

$query1 = "SELECT * FROM recruit.loginInfo WHERE username='$email_or_username' AND password='$password'";

$result1 = mysqli_query($dbcon, $query1);
$numResults1 = mysqli_num_rows($result1);

#echo "<script type='text/javascript'>alert( '$numResults1'+'$password' );</script>";

if($numResults1 == 1) {
    $row1 = $result1->fetch_assoc();
    session_start();
    #echo "<script type='text/javascript'>alert( 'sahi hai' );</script>";
    $_SESSION['username'] = $row1['username'];
    $_SESSION['user_type'] = 1;
    header('location:../employer/home.php');
} else {
    #echo "<script type='text/javascript'>alert( 'chi chi' );</script>";
    header('location:logins.php');
}
?>
