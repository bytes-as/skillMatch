# job_portal

Job portal is an application which connects employer and job seekers where employers are the source of the resources and the job seeker can find and apply for their targeted job. 

#Features
•	People can register as job seekers, build their profiles, and look for jobs matching their skill sets.
•	People can apply directly to posted jobs.
•	Companies can register, post jobs, and search job seeker profiles
•	Multiple representatives from a company should be able to register and post jobs.
•	Company representatives can view a list of job applicants and can contact them, initiative an interview, or perform some other action related to their post.
•	Registered users should be able to search for jobs and filter the results based on location, required skills, salary, experience level, etc
Users can upload their existing resumes. If they do not have one, they should be able to fill out a form and have a resume built for them.

